import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-number-nav',
  templateUrl: './number-nav.component.html',
  styleUrls: ['./number-nav.component.scss']
})
export class NumberNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
